<html>
	<head>
		<link rel="STYLESHEET" TYPE="TEXT/CSS" HREF="../style/style_php.CSS">      
		<title>Insert</title>
		<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../style/style.css">
	<link rel="stylesheet" href="../style/garage.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
        <style>
			label {
    display: block;
    font: 1rem 'Fira Sans', sans-serif;
}

input,
label {
    margin: .4rem 0;
}

        </style>
	</head>
	<body>
		<?php
    session_start();
	$userID = $_SESSION['userID'];
	$session = $_SESSION['session'];
	include("../../module/connection.php");
	include("../../includes/navigation/garage-navigation-bar.php");
	$link=KonektatuDatuBasera();

	$Tweek = strftime('%V');
	
	$week = $_SESSION['week'];
	$date = $_SESSION['date'];
?>


	<div id='total'>
	 	<div id='selectedHours'>
			 <h2>Selected hours:</h2>
			 <div>
			 <?php 
			 $showHours = mysqli_query($link,"select Hours from garage_1 where session = '$session' and buy = '0'");
			 if(mysqli_num_rows($showHours)!=0){
			 $showHours = mysqli_fetch_array($showHours);
			 $showHours = $showHours[0];
			 $showHoursArray = explode("_", $showHours);
			 echo $Hours1 = intval($showHoursArray[0]);
			 echo "<br>";
			 echo $Hours2 = intval($showHoursArray[1]);
			 echo "<br>";
			 echo strftime('%a',$Hours2);


			}
			 
			 
			 
			 ?>
			 </div>
		</div>
		<div id='selectedProducts'>
			<h2>Selected products:</h2>
			<div>

			</div>
		</div>
	</div>



<a href="garage-buy.php">
		<button type="button" class="btn btn-primary btn-lg">Confirm</button>
	</a>
	</body>
	</html>