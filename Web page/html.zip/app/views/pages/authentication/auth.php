<!-- Head -->

<head>
    <title>Login / Sign Up</title>
    <link rel="stylesheet" href="./authentication.css">

    <?php
    include_once("../../../includes/head/head.php");
    ?>
</head>



<body>
  <!-- Navigation bar -->
  <?php
  session_start();
  include("../../../includes/navigation/navigation-bar.php");
  ?>


  <div id="loginSignUp">
    <!-- LOGIN -->
    <div id="loginForm">
      <h2>Sign In</h2>
      <form action="../../../authentication/signin.php" method="post">


        <div class="form-group">
          <label>E-mail address:</label>
          <input type="text" class="form-control" id="izena" placeholder="E-mail address" name="email">
        </div>

        <div class="form-group">
          <label>Password:</label>
          <input type="password" class="form-control" id="pasahitza" placeholder="Password" name="password">
        </div>

        <button type="submit" class="btn btn-primary bidali">Sign in</button>
        <button type="reset" class="btn btn-secondary">Clear</button>
      </form>

      <!-- LOGIN DATUAK SARTU ONDOREN -->
      <?php
      if (isset($_GET["okerra"])) {
        if ($_GET["okerra"] == "bai") {
      ?>

          <p style="color:#F00">
            <b>Incorrect address or password</b>
          </p>
      <?php
        }
      }
      ?>

    </div>



    <!-- SIGN UP -->
    <div id="SignUpForm">
      <h2>Sign Up</h2>
      <form action="../../../authentication/signup.php" method="post">


        <div class="form-group">
          <label>Name:</label>
          <input type="text" class="form-control" id="izena" placeholder="Name" name="name" required>
        </div>

        <div class="form-group">
          <label>Surname:</label>
          <input type="text" class="form-control" id="izena" placeholder="Surname" name="surname" required>
        </div>

        <div class="form-group">
          <label>E-mail address:</label>
          <input type="email" class="form-control" id="izena" placeholder="example@domain.com" name="email" required>
        </div>

        <div class="form-group">
          <label>Phone number:</label>
          <input type="text" class="form-control" id="izena" placeholder="123456789" name="phone" required>
        </div>

        <div class="form-group">
          <label>Password:</label>
          <input type="password" class="form-control" id="pasahitza" placeholder="Password" name="password" required>
        </div>

        <button type="submit" class="btn btn-success bidali">Create account</button>
        <button type="reset" class="btn btn-secondary">Clear</button>
      </form>



      <!-- SIGN UP DATUAK SARTU ONDOREN -->

      <?php
      if (isset($_GET["erregistratu"])) {
        if ($_GET["erregistratu"] == "ez") {
      ?>

          <p style="color:#F00">
            <b>This email already exists, try another one.</b>
          </p>
      <?php
        }
      }
      ?>
      <?php
      if (isset($_GET["erregistratu"])) {
        if ($_GET["erregistratu"] == "bai") {
      ?>

          <p style="color:#0F0">
            <b>Account created successfully</b>
          </p>
      <?php
        }
      }
      ?>
    </div>
  </div>

  <!-- Footer -->
  <?php
  include("../../../includes/footer/footer.php");
  ?>
</body>

</html>