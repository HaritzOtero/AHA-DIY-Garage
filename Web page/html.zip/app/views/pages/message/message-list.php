<html>
<head>
    <title>AHA DIY Garage</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./message.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    <style>
    </style>
</head>
    <body>
    <?php
    session_start();
    
    $name = $_SESSION['name'];
    $userID = $_SESSION['userID'];
    $position = $_SESSION['position'];
    $session = $_SESSION['session'];


	include("../../../module/connection.php");
    include("../../../includes/navigation/navigation-bar.php");
	$link=KonektatuDatuBasera();
?>
<H1>Client Messages</H1>
			<?php
			
				$emaitza=mysqli_query($link,"select * from message");
				
			?>

        <table border='1'>
		<tr>
        <Th>Client information</Th><Th>Message</Th>
		</tr>
				<?php
					while($erregistroa = mysqli_fetch_array($emaitza))
					{
printf("
                        

		<tr>
					<td>
                        <table border='1'>
                        <tr>
                                <td> %s </td>
                            </tr>
                            <tr>
                                <td> %s </td>
                            </tr>
                            <tr>
                                <td> %d </td>
                            </tr>
                        </table>
                    </td>
			        <td> <div style='word-wrap: break-word:'></div>%s </td>
        </tr>
        	
", $erregistroa["name"], $erregistroa["email_address"], $erregistroa["phone_number"], $erregistroa["message"]);              		
} 
             ?>
</table>

	</body>
</html>

