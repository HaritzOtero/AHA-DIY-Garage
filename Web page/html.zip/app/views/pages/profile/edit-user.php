
    <?php
			include("../../../module/connection.php");

            $client_id = $_POST["client_id"];
            $name=$_POST["name"];
            $surname=$_POST["surname"];
            $email_address=$_POST["email_address"];
            $phone_number=$_POST["phone_number"];
            $password=$_POST["password"];

            echo $client_id;
            echo gettype($client_id);
            echo "<br>";
            echo $name;
            echo gettype($name);
            echo "<br>";
            echo $surname;
            echo gettype($surname);
            echo "<br>";
            echo $email_address;
            echo gettype($email_address);
            echo "<br>";
            echo $phone_number;
            echo gettype($phone_number);
            echo "<br>";
            echo $password;
            echo gettype($password);



            $link=KonektatuDatuBasera();

            mysqli_query($link,"update client set name = '$name',
                                                      surname = '$surname',
                                                      email_address = '$email_address',
                                                      phone_number = '$phone_number',
                                                      password = '$password'
                                                      where client_id = '$client_id'");
        	header("Location:./profile.php?user_edited");
?>