
    <?php
	include("../../../module/connection.php");
	$link=KonektatuDatuBasera();


	$id = $_GET["client_id"];

			
	$link=KonektatuDatuBasera();
	mysqli_query($link,"delete from client where client_id = '$id'");
	header("Location:../authentication/auth.php?user_deleted");

?>

