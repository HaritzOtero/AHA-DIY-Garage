<!-- head -->

<head>
    <title>Login / Sign Up</title>
    <link rel="stylesheet" href="./profile.css">

    <?php
    include_once("../../../includes/head/head.php");
    ?>
</head>

<body>
    <!-- Navigation bar -->
    <?php
    session_start();    
    $userID = $_SESSION['userID'];
    include("../../../includes/navigation/navigation-bar.php");
    ?>
    <script>
function Info() {
    document.getElementById('userInformation').style.display='block';
    document.getElementById('userInformationForm').style.display='none';
}
function Form() {
    document.getElementById('userInformation').style.display='none';
    document.getElementById('userInformationForm').style.display='block';
}
</script>



    <div class="UserProfile">

        <div class="profileDiv">
            <div class="imageAndOptions">
                <div class="image">
                    <img src="../../../../assets/images/user/login_icon.png" alt="" class="ProfileUserIcon">
                </div>
                <div class="options">
                    <div>
                        <a href="../../../authentication/logout.php">
                            <button type="button" class="btn btn-primary">Log Out</button>
                        </a>
                    </div>
                    <div>
                    <!-- <button type='button' class='btn btn-danger' data-toggle='modal' data-target='#ModalDelete'> Delete account</button> -->

                    </div>

                </div>
            </div>
        </div>

        <div class="profileDiv">
            <div class="UserInformation">
            

                <?php
                include("Location:../../../../../module/connection.php");
                $link = KonektatuDatuBasera();
                if (isset($_SESSION['position'])) {
                    $erregistroa = mysqli_query($link,"select * from employee where employee_id = $userID");
                    $erregistroa = mysqli_fetch_array($erregistroa);
                    printf("
                <div class='privateInformation'>
                    <p>
                        ID: %s
                    </p>
                </div>
                <div class='privateInformation'>
                    <p>
                        Name: %s
                    </p>
                </div>
                <div class='privateInformation'>
                    <p>
                        Surname: %s
                    </p>
                </div>
                <div class='privateInformation'>
                    <p>
                        Address: %s
                    </p>
                </div>
                <div class='privateInformation'>
                    <p>
                        Phone number: %s
                    </p>
                </div>
                <div class='privateInformation'>
                    <p>
                        Age: %s
                    </p>
                </div>
                <div class='privateInformation'>
                    <p>
                        Salary: %s
                    </p>
                </div>
                <div class='privateInformation'>
                    <p>
                        Position: %s
                    </p>
                </div>
                <div class='privateInformation'>
                    <p>
                        Password: %s
                    </p>
                </div>
", $erregistroa["employee_id"], $erregistroa["name"], $erregistroa["surname"], $erregistroa["adress"], $erregistroa["phone_number"], $erregistroa["age"], $erregistroa["salary"], $erregistroa["position"], $erregistroa["password"]);

                } else {
                    $erregistroa = mysqli_query($link,"select * from client where client_id = $userID");
                    $erregistroa = mysqli_fetch_array($erregistroa);
                    printf("
                    <div id='userInformation' style='display:block;border:1px solid green;'>
                        <div class='privateInformation'>
                            <p>
                                name: %s
                            </p>
                        </div>
                        <div class='privateInformation'>
                            <p>
                                surname: %s
                            </p>
                        </div>
                        <div class='privateInformation'>
                            <p>
                                email: %s
                            </p>
                        </div>
                        <div class='privateInformation'>
                            <p>
                                phone: %s
                            </p>
                        </div>
                        <div class='privateInformation'>
                            <p>
                                password: %s
                            </p>
                        </div>
                        <button style='display:block' class='btn btn-warning' type='button' onclick='Form()'>Edit</button>
                    </div>                    
", $erregistroa["name"], $erregistroa["surname"], $erregistroa["email_address"], $erregistroa["phone_number"], $erregistroa["password"]);

printf("
<div id='userInformationForm' style='display:none'>
    <form action='./edit-user.php' method='post'>

    <input style='display:none' type='text' class='form-control' id='izena' placeholder='ID' value='%s' name='client_id' required>

    <div class='form-group'>
    <label>Name:</label>
    <input type='text' class='form-control' id='izena' placeholder='Name' value='%s' name='name' required>
    </div>
    <div class='form-group'>
    <label>Surname:</label>
    <input type='text' class='form-control' id='izena' placeholder='Name' value='%s' name='surname' required>
    </div>
    <div class='form-group'>
    <label>Email address:</label>
    <input type='text' class='form-control' id='izena' placeholder='Name' value='%s' name='email_address' required>
    </div>
    <div class='form-group'>
    <label>Phone number:</label>
    <input type='number' class='form-control' id='izena' placeholder='Name' value='%d' name='phone_number' required>
    </div>
    <div class='form-group'>
    <label>Password:</label>
    <input type='text' class='form-control' id='izena' placeholder='Name' value='%s' name='password' required>
    </div>

    <button type='submit' class='btn btn-success bidali'>Apply changes</button>
    </form>
    <button style='display:block' class='btn btn-secondary' type='button' onclick='Info()'>Close</button>
    
</div>
",$erregistroa["client_id"], $erregistroa["name"], $erregistroa["surname"], $erregistroa["email_address"], $erregistroa["phone_number"], $erregistroa["password"]);
?>
    <!-- <div class='modal fade' id='ModalDelete' tabindex='-1' role='dialog' aria-labelledby='exampleModalCenterTitle' aria-hidden='true'>
        <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLongTitle">Delete product</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <p>You are about to delete your account. Are you sure that you want to delete your account?
          </p>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->
              <?php 
            //   printf("<a href='./delete-user.php?client_id=%s'>",$erregistroa["client_id"])
              ?>
              <!-- <button type="button" class="btn btn-danger">Delete acount</button>
              </a>
            </div>
          </div>
        </div>
      </div> -->
      <?php
                }
                ?>
            </div>
        </div>

    </div>


    <!-- Footer -->
    <?php
    include("../../../includes/footer/footer.php");
    ?>
</body>

</html>