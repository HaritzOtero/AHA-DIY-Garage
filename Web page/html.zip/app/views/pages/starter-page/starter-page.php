<!-- head -->
<head>
<link rel="stylesheet" href="./starter-page.css">
</head>
<?php
include_once("../../../includes/head/head.php");
?>

<body>
    <!-- Navigation bar -->
    <?php
    session_start();
    include("../../../includes/navigation/navigation-bar.php");
    ?>

    <!-- Slider -->
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner ">
            <div class="carousel-item active">
                <img class="d-block w-100" src="../../../../assets/images/garage/pexels-andrea-piacquadio-3807226.jpg" alt="Second slide" style="height: 50vh; object-fit: cover; filter: blur(0px);" />
                <div class="carousel-caption text-align-center">
                    <h1 class="font-weight-bold">AHA DIY Garage</h1>
                    <h3>The Do Yourself Garage</h3>
                </div>
            </div>
            <div class="carousel-item">
                <img class="d-block w-100" src="../../../../assets/images/garage/pexels-andrea-piacquadio-3807277.jpg" alt="Second slide" style="height: 50vh; object-fit: cover; filter: blur(0px);" />
                <div class="carousel-caption text-align-center">
                    <h1 class="font-weight-bold">Learn more about the DIY Garage</h1>
                    <a href="./views/pages/about-us/about-us.php" class="btn btn-primary">About us!</a>
                </div>
            </div>
            <div class="carousel-item">
                <img class="d-block w-100" src="../../../../assets/images/garage/pexels-andrea-piacquadio-3807329.jpg" alt="Third slide" style="height: 50vh; object-fit: cover; filter: blur(0px);" />
                <div class="carousel-caption text-align-center">
                    <h1 class="font-weight-bold">Contact us!</h1>
                    <a href="./views/pages/contact/contact.php" class="btn btn-primary">Contact</a>
                </div>
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

    <!-- Main information -->
    <!-- container information one -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm d-flex border align-items-center justify-content-center p-4">
                <img src="../../../../assets/images/garage/outside.jpg" class="w-50">
            </div>
            <div class="col-sm d-flex border align-items-center justify-content-center p-4">
                <div class="w-50">
                    <h1>AHA DIY Garage</h1>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ut, deleniti ab laboriosam minima et cum at inventore saepe esse temporibus unde hic doloribus maxime alias! Labore suscipit neque, eius minus, mollitia maiores voluptatibus molestias facere deleniti numquam esse dolorem excepturi!</p>
                </div>
            </div>
        </div>
    </div>

    <!-- container information two -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm d-flex border align-items-center justify-content-center p-4">
                <div class="w-50">
                    <h1>Inside one of our cabins</h1>
                    <p>Sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
                </div>
            </div>
            <div class="col-sm d-flex border align-items-center justify-content-center p-4">
                <img src="../../../../assets/images/garage/inside.jpg" class="w-50">
            </div>
        </div>
    </div>

    <!-- container information renting -->
    <div class="container-fluid">
        <div class="d-flex align-items-center justify-content-center p-4">
            <div class="text-center">
                <h1>Rent now!</h1>
                <a href="../renting/renting.php"><img src="../../../../assets/images/garage/rent.png" style="border-radius: 10px;"></a>
                <p>👆Go to rentings!👆</p>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php
    include("../../../includes/footer/footer.php");
    ?>
</body>

</html>