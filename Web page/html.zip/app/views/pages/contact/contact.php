<!-- Head -->
<head>
<link rel="stylesheet" href="./contact.css">
</head>
<?php
include_once("../../../includes/head/head.php");

?>

<body>
    <!-- Navigation bar -->
    <?php
    session_start();
    include("../../../includes/navigation/navigation-bar.php");
    ?>

    <div class="container" style="margin-top:30px; background-color: white;">
        <div class="row">
            <div class="col-sm">
                <div>
                    <h6 class="underLine">CONTACT</h6>
                </div>
                <div class="mt-3">
                    <p>Email: ahagarage@gmail.com</p>
                    <p>Phone number: 633457021</p>
                    <p>Location: Eibar</p>
                </div>
                <div>
                    <h6 class="underLine">SOCIAL MEDIA</h6>
                </div>
                <div class="container">
                    <!--Instagram-->
                    <div class="row mt-3">
                        <div class="col-sm">
                            <img src="../../../../assets/images/social-media/instagram.webp" style="width: 50px; height: 50px;">
                        </div>
                        <div class="col-sm mt-3 mr-5">
                            <p class="socialMedia rounded-circle">@ahaGarage</p>
                        </div>
                    </div>
                    <!--Twitter-->
                    <div class="row mt-3">
                        <div class="col-sm">
                            <img src="../../../../assets/images/social-media/twitter.jpg" style="width: 50px; height: 50px;">
                        </div>
                        <div class="col-sm mt-3 mr-5">
                            <p class="socialMedia rounded-circle">@ahaGarage</p>
                        </div>
                    </div>
                    <!--Facebook-->
                    <div class="row mt-3">
                        <div class="col-sm">
                            <img src="../../../../assets/images/social-media/facebook.png" style="width: 50px; height: 50px;">
                        </div>
                        <div class="col-sm mt-3 mr-5">
                            <p class="socialMedia rounded-circle">@ahaGarage</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm">
                <img src="../../../../assets/images/logo/logo.png" style="width: 550px; height: 300px;">
            </div>
            <div class="col-sm">
                <div>
                    <h6 class="underLine">SCHEDULE</h6>
                </div>
                <div class="mt-3">
                    <p>MONDAY: 8:00-22:00</p>
                    <p>TUESDAY: 8:00-22:00</p>
                    <p>WEDNESDAY: 8:00-22:00</p>
                    <p>THURSDAY: 8:00-22:00</p>
                    <p>FRIDAY: 8:00-22:00</p>
                    <p>SATURDAY: 8:00-22:00</p>
                    <p>SUNDAY: CLOSED</p>
                </div>
            </div>
        </div>
    </div>

    <!--Send a message-->
    <div class="container mt-5">
        <div>
            <div>
                <h2>Send a message</h2>
            </div>
            <div class="mt-3">
                <form action="./contact-message.php" method="post">
                    <div class="container">
                        <!--1.row-->
                        <div class="row">
                            <div class="col-sm">
                                <div class="form-group">
                                    <label >Name:</label>
                                    <input type="text" class="form-control" placeholder="Enter name" id="name" name="name" required>
                                </div>
                                <div class="form-group">
                                    <label >Email address:</label>
                                    <input type="email" class="form-control" placeholder="Enter email" id="email" name="email" required>
                                </div>
                                <div class="form-group">
                                    <label >Phone number:</label>
                                    <input type="number" class="form-control" placeholder="Enter number" id="phone" name="phone" required>
                                </div>
                            </div>
                            <div class="col-sm">
                                <div class="form-group">
                                    <label >Message:</label>
                                    <textarea class="form-control" placeholder="Enter message" rows="5" maxlength="500" id="comment" name="comment" required></textarea>
                                </div>
                                <div>
                                    <button type="submit" class="btn btn-primary">Send Message</button>
                                </div>

                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

    </div>

    <!-- Footer -->
    <?php
    include("../../../includes/footer/footer.php");
    ?>

</body>

</html>