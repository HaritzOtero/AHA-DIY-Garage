<!-- head -->
<head>
<link rel="stylesheet" href="./renting.css">
</head>
<?php
include_once("../../../includes/head/head.php");
?>

<body>
    <?php
    session_start();
    if (!isset($_SESSION['name'])) {
        header("Location:../authentication/auth.php?logeatu=logeatu");
    }
    ?>

    <!-- Navigation bar -->
    <?php
    include("../../../includes/navigation/navigation-bar.php");
    ?>


    </div>

    <div class="garagesDiv">

        <div class="garage">
            <div class="garageElement">
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus ultricies commodo nisl, vel hendrerit urna posuere ut. Quisque feugiat accumsan purus tincidunt consectetur. Donec tincidunt eget libero vel congue. Nam tempus sapien in posuere dapibus. Donec porttitor convallis leo, nec semper sapien euismod eget. Sed tempor nibh eu consequat ultrices. Nulla volutpat semper sapien sed dapibus. Aenean eget metus arcu. Sed ipsum tellus, viverra id mi non, fermentum accumsan ex. Donec non eros id urna tincidunt pellentesque. Praesent nec vulputate quam.
                </p>

            <a class="nav-link" href="../../../requests/garage-1/garage.php">GARAGE 1</a>

            </div>
        </div>

        <div class="garage">
            <div class="garageElement">
                <p>
                    Maecenas at luctus odio. Praesent enim tellus, rhoncus sit amet nulla sit amet, scelerisque faucibus neque. Maecenas pretium vel justo eget aliquet. Nulla magna eros, consequat eget nulla eget, blandit vulputate sem. In congue sit amet dolor ac tristique. Donec consectetur accumsan diam, quis euismod magna tempus ac. Morbi dictum nunc et justo gravida pellentesque. Suspendisse sollicitudin dignissim euismod.
                </p>

                <a class="nav-link" href="#">GARAGE 2</a>

            </div>
        </div>

        <div class="garage">
            <div class="garageElement">
                <p>
                    Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Integer varius ut velit id varius. Sed aliquet eros quam, lacinia pharetra massa tempus pulvinar. Vestibulum ullamcorper, ex eu dictum fermentum, erat odio mollis nulla, eu aliquet mi orci tristique elit. Donec eros lacus, suscipit sit amet nibh a, fringilla dignissim mi. Vivamus fringilla eu dolor ut rutrum. Duis suscipit vehicula ante, a ultricies urna sodales nec. Curabitur dui orci, tempor eu arcu eu, faucibus malesuada mauris. Pellentesque sed dignissim risus. Cras enim quam, condimentum sed orci eget, viverra dapibus lectus.
                </p>

                <a class="nav-link" href="#">GARAGE 3</a>

            </div>
        </div>
    </div>



    <!-- Footer -->
    <?php
    include("../../../includes/footer/footer.php");
    ?>
</body>

</html>