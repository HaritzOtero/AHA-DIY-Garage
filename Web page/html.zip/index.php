<?php
header('Location: ./app/views/pages/starter-page/starter-page.php');
